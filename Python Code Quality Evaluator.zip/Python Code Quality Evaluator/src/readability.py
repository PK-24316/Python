import ast

MAX_FUNCTION_LENGTH = 40
BAD_NAMES = {"x", "y", "tmp", "data", "var"}

HIGH_SEVERITY = {
    "too long": 3
}

MEDIUM_SEVERITY = {
    "poor name": 2
}

LOW_SEVERITY = {
    "non-descriptive": 1
}

def analyze_readability(tree):
    issues = set()
    score_penalty = 0

    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            length = len(node.body)
            if length > MAX_FUNCTION_LENGTH:
                issues.add(f"Function '{node.name}' is too long ({length} lines).")
                score_penalty += HIGH_SEVERITY["too long"]

            for arg in node.args.args:
                if arg.arg in BAD_NAMES:
                    issues.add(
                        f"Poor parameter name '{arg.arg}' in function '{node.name}'."
                    )
                    score_penalty += MEDIUM_SEVERITY["poor name"]

        if isinstance(node, ast.Name):
            if node.id in BAD_NAMES:
                issues.add(f"Non-descriptive variable name '{node.id}' used.")
                score_penalty += LOW_SEVERITY["non-descriptive"]

    issues = sorted(list(issues))

    # Normalize score (0-10)
    score = max(0, 10 - score_penalty)

    return {"score": score, "issues": issues}

      