import ast

DANGEROUS_CALLS = {"eval", "exec", "pickle", "subprocess"}

def analyze_security(tree):
    issues = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                if node.func.id in DANGEROUS_CALLS:
                    issues.append(f"Use of dangerous function '{node.func.id}'")

    score = max(0, 10 - len(issues))
    return {"score": score, "issues": issues}
