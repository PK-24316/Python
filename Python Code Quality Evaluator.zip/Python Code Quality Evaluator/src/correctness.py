import subprocess
import tempfile
import sys

def run_correctness_check(code):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
        tmp.write(code)
        filename = tmp.name

    result = subprocess.run(
        [sys.executable, filename],
        capture_output=True,
        text=True
    )

    return {
        "exit_code": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "passed": result.returncode == 0
    }
