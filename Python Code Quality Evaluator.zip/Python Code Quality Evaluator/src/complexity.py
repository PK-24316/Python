import ast

def calculate_complexity(tree):
    complexity = 1
    
    for node in ast.walk(tree):
        if isinstance(node, (ast.If, ast.For, ast.While, ast.And, ast.Or, ast.Try)):
            complexity += 1
        
    score = max(0, 10 - complexity)
    return {
        "cyclomatic_complexity": complexity,
        "score": score,
        "note": "Higher complexity increases cognitive load."
    }