def generate_report(results):
    total_score = sum(section.get("score", 0) for section in results.values())

    return {
        "summary": {
            "total_score": total_score,
            "risk_level": (
                "High" if total_score < 15 else
                "Medium" if total_score < 25 else
                "Low"
            )
        },
        "details": results
    }
