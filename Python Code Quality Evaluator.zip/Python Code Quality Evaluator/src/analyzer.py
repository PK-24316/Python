import ast
from .readability import analyze_readability
from .complexity import calculate_complexity
from .security import analyze_security
from .correctness import run_correctness_check
from .report import generate_report


def analyze_code(code):
    tree = ast.parse(code)

    results = {
        "readability": analyze_readability(tree),
        "complexity": calculate_complexity(tree),
        "security": analyze_security(tree),
        "correctness": run_correctness_check(code)
    }

    print(__package__)
    return generate_report(results)
