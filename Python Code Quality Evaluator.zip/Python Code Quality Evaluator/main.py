from src.analyzer import analyze_code
import json
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAMPLES_DIR = os.path.join(BASE_DIR, "samples")

if __name__ == "__main__":
    file_path = os.path.join(SAMPLES_DIR, "bad_code.py")

    with open(file_path) as f:
        code = f.read()

    report = analyze_code(code)
    print(json.dumps(report, indent=4))
