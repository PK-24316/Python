def f(x, y):
    if x > 0:
        if y > 0:
            print(x + y)
        else:
            print(x)
    else:
        print(y)

f(1, 2)
