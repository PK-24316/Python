user_input = "2 + 2"
result = eval(user_input)
print(result)
