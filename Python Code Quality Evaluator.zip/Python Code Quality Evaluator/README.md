# Python Code Quality Evaluator (Mini AI Judge)

A Python-based code evaluation tool designed to assess Python code quality across readability, complexity, security, and correctness. The tool produces structured, explainable reports with reproducible error traces—simulating the process of evaluating and improving AI-generated code.

This project is built to demonstrate:
- Code analysis using AST (Abstract Syntax Tree)
- Clear, modular software architecture
- Failure-mode documentation and reproducible debugging
- Weighted scoring and explainable feedback

---

## 🔍 Purpose

The goal of this project is to create a lightweight evaluation engine that can:
- Identify common coding issues
- Detect security risks
- Measure complexity and readability
- Execute code safely to verify correctness
- Provide clear feedback and structured reports

This mirrors the responsibilities of an AI coding trainer: evaluating code output, capturing failure modes, and suggesting improvements.

---

## 🚀 Features

### ✅ Readability Analysis
Checks for:
- Poor variable names
- Poor parameter names
- Long functions
- Duplicated issues removed

### ✅ Complexity Analysis
Measures cyclomatic complexity using AST and assigns a score.

### ✅ Security Analysis
Detects unsafe patterns such as:
- `eval`
- `exec`
- `pickle`
- `subprocess`

### ✅ Correctness Check
Executes code in a sandboxed subprocess and captures:
- stdout
- stderr
- exit code

### ✅ Structured Report Output
Outputs results in JSON format with:
- Total score
- Risk level
- Detailed section breakdown

---

## 🧱 Project Structure


---

## 🧠 How It Works

1. **Parse code using AST**
2. **Run readability, complexity, and security checks**
3. **Execute code to verify correctness**
4. **Generate a structured report**

---

## 📌 Usage

From the project root:

```bash
python main.py
{
  "summary": {
    "total_score": 19,
    "risk_level": "Medium"
  },
  "details": {
    "readability": {
      "score": 2,
      "issues": [
        "Poor parameter name 'x' in function 'f'.",
        "Poor parameter name 'y' in function 'f'.",
        "Non-descriptive variable name 'x' used."
      ]
    },
    "complexity": {
      "cyclomatic_complexity": 3,
      "score": 7,
      "note": "Higher complexity increases cognitive load."
    },
    "security": {
      "score": 10,
      "issues": []
    },
    "correctness": {
      "exit_code": 0,
      "stdout": "3\n",
      "stderr": "",
      "passed": true
    }
  }
}
